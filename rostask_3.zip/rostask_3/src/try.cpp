#include "ros/ros.h"
#include <std_msgs/Float64.h>
#include <sstream>

int main(int argc, char **argv)
{
ros::init(argc, argv,"Numbers");
ros::NodeHandle n;
ros::Publisher chatter_pub=n.advertise<std_msgs::Float64>("initial",1000);
ros::Rate loop_rate(1);

float count1=10.0,count2=20.0;
while(count1==10.0)
{
std_msgs::Float64 num1, num2,prod;
num1.data=count1;
num2.data=count2;
prod.data=num1.data*num2.data;
ROS_INFO("%.2f",num1.data);
ROS_INFO("%.2f",num2.data);
chatter_pub.publish(prod);
ros::spinOnce();
loop_rate.sleep();
count1++;
return 0;
} 


