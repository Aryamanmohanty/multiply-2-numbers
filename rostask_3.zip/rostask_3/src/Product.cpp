#include "ros/ros.h"
#include <std_msgs/Float64.h>
#include <sstream>

void callback1(const std_msgs::Float64::ConstPtr& prod)
{
ROS_INFO("%0.2f",prod->data);
}

int main(int argc,char **argv)
{
ros::init(argc,argv, "Product");
ros::NodeHandle n;
ros::Subscriber sub =n.subscribe("initial",1000,callback1);
ros::spin();

return 0;
}

